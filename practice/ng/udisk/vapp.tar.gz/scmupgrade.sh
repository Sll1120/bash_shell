#  /bin/sh
#!/bin/bash

PREF=""
#****************
#debug
#PREF="/mnt/h/ts"
#****************
VAPP_PATH=${PREF}"/mnt/res"
OTA_PATH=${PREF}"/mnt/udisk/vota"
APP_PATH=${VAPP_PATH}/vapp
SCM_DONE=${APP_PATH}/scm.finished


SCM_ZIP_FILES=${OTA_PATH}/scm*.zip
ROOT_ZIP_FILES=${OTA_PATH}/root*.zip

NEED_TO_REBOOT=0

if [ -f ${APP_PATH}/scm.finished ];then
	echo "Upgrade already finished, cleanup..."
	rm ${OTA_PATH} -r
	sync
	exit
else
	if [ -f $SCM_ZIP_FILES ]
	then
		for z in $SCM_ZIP_FILES; 
			do echo "Files found:" $z
			unzip -o $z -d $VAPP_PATH
		done
	fi
	if [ -f $ROOT_ZIP_FILES ]
	then
		kill -9 $(pidof Roboeye_server)
		kill -9 $(pidof cond)
		kill -9 $(pidof devd)
		kill -9 $(pidof logd)
		kill -9 $(pidof mosquitto)
		kill -9 $(pidof lighttpd)
		kill -9 $(pidof appd)
		kill -9 $(pidof wlan_serverd)	
		for z in $ROOT_ZIP_FILES; 
				do echo "Files found: " $z
				unzip -o $z -d /
			echo $z
		done
		NEED_TO_REBOOT=1
	fi
	sync
	chmod +x ${APP_PATH}/setup.sh && ${APP_PATH}/setup.sh
	touch $SCM_DONE
	sync
	reboot
fi
