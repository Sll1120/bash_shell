#!/bin/sh
#
# System-specific script to configure the DHCP client, server, and Wi-Fi
# module.  This script is invoked by the Ayla cond daemon when transitioning
# between varioius modes of operation.
# 
# Note: This is a sample script written for a system using wpa_supplicant and
# hostapd and may need to be modified or rewritten to provide the desired
# functionality for the target platform.
#

print_usage() {
	echo "usage: $0 <module> <action> [interface] [IP addr]|[SSID] [channel] [security] [key]" >&2
	exit 1
}

function start_dns_client() {
	local name="$1"
	#kill anyway
	kill -9 $(pidof $name)

	echo "start_daemon: starting $name..."
	/sbin/$name  -i wlan0 -b
	return $?
}

function ap_start() {
	#kill anyway
	killall hostapd

	echo "ctrl_interface=/var/run/hostapd" > /var/run/hostapd.conf
	echo "interface=$interface"            >> /var/run/hostapd.conf
	echo "driver=nl80211"                  >> /var/run/hostapd.conf
	echo "ssid=$ssid"                      >> /var/run/hostapd.conf
	echo "channel=$channel"                >> /var/run/hostapd.conf
	echo "hw_mode=g"                       >> /var/run/hostapd.conf
	echo "auth_algs=1"                     >> /var/run/hostapd.conf
	sync

	hostapd -P/var/run/hostapd.pid -B /var/run/hostapd.conf
}

function start_dns_server() {
	#kill anyway
	killall dnsmasq

	echo "user=root"  > /tmp/dnsmasq.conf
	echo "listen-address=$ip_address" >> /tmp/dnsmasq.conf
	echo "dhcp-range=${ip_address%.*}.50, ${ip_address%.*}.150" >> /tmp/dnsmasq.conf
	echo "server=/google/8.8.8.8"    >> /tmp/dnsmasq.conf
	sync

	ifconfig $interface $ip_address netmask 255.255.255.0
	dnsmasq -C /tmp/dnsmasq.conf
}

function station_start() {
	#kill anyway
    killall wpa_supplicant

    echo "ctrl_interface=/var/run/wpa_supplicant"  > /tmp/wpa_supplicant.conf
    echo "update_config=1"  >> /tmp/wpa_supplicant.conf
    echo "network={"  >> /tmp/wpa_supplicant.conf
    echo "ssid=\"$ssid\""  >> /tmp/wpa_supplicant.conf
    echo "psk=\"$passwd\""  >> /tmp/wpa_supplicant.conf
    echo "priority=5"  >> /tmp/wpa_supplicant.conf
    echo "}"  >> /tmp/wpa_supplicant.conf

    wpa_supplicant -i$interface -Dnl80211 -c/tmp/wpa_supplicant.conf -B
}

if [ $# -lt 2 ]; then
	echo "incorrect arguments" >&2
	print_usage
fi

module="$1"
action="$2"
interface="$3"
ip_address="$4"
ssid="$4"
channel="$5"
passwd="$5"
security="$6"
key="$7"

case $module-$action in
	station-start)
		echo "$0: station start"
		station_start
	;;
	station-stop)
		echo "$0: station stop"
		killall wpa_supplicant
	;;
	ap-start)
		echo "$0: AP start"
		ap_start
	;;
	ap-stop)
		echo "$0: AP stop"
		killall hostapd
	;;
	dhcp-client-start)
		echo "$0: DHCP client start"
    	start_dns_client "udhcpc"
	;;
	dhcp-client-stop)
		echo "$0: DHCP client stop"
		killall udhcpc
	;;
	dhcp-server-start)
		echo "$0: DHCP server start"
		start_dns_server
	;;
	dhcp-server-stop)
		echo "$0: DHCP server stop"
		#stop_daemon "dnsmasq"
		killall dnsmasq
	;;
	*)
		echo "$0: invalid command: $module-$action" >&2
		print_usage
	;;
esac

exit 0
